#!/bin/bash

if test -f "/home/pi/turnon"; then
	echo "turn on pf"
	/opt/sdm630/sdm630_on
	sudo rm /home/pi/turnon
fi

if test -f "/home/pi/turnoff"; then
	echo "turn off pf"
	/opt/sdm630/sdm630_off
	sudo rm /home/pi/turnoff
fi
