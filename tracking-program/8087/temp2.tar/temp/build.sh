gcc sdm630-usb.c -o sdm630 `pkg-config --cflags --libs libmodbus`
