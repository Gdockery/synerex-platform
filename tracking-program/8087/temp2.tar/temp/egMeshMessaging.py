
from EGCommon.egLogging import log
import time
import datetime
import subprocess
import json
import Queue
import os.path
from egMeshClient import EGMeshClient
from egMeshMessage import EGMeshMessage
from EGCommon.egUtils import *


class EGMeshMessagingGeneric(object):
    def __init__(self):
        self.client = EGMeshClient()
        self.highPriorityInterval = 5
        self.lowPriorityInterval = 60

        self.meshMessageExpireInterval = 10 * 60
        self.lastMeshMessage = None

        now = int(time.time())
        self.__lastCheckHigh = now
        self.__lastCheckLow = now

    def addMessage(self, type, outgoing=False, data=None):
        self.client.messageRequests.put(EGMeshMessage(type, outgoing, data))

    def handleMessages(self):
        now = int(time.time())
        if now - self.__lastCheckHigh > self.highPriorityInterval:
            self.addHighPriorityMessages()
            self.__lastCheckHigh = now

        if now - self.__lastCheckLow > self.lowPriorityInterval:
            self.addLowPriorityMessages()
            self.__lastCheckLow = now

        self.client.communicate()

        try:
            data = self.client.messageResponses.get_nowait() # client.communicate has it's own timeout
            if data is not None:
                self.handleResponse(data)
        except Queue.Empty:
            pass

    def addHighPriorityMessages(self):
        log.error("Must implement")

    def addLowPriorityMessages(self):
        log.error("Must implement")

    def handleResponse(self, meshData):
        pass

# ------------------------------------------------------------------------------------------------------------------
#
# With MESH only communication runs on a GATEWAY: Gathers data from sensor nodes
#
class EGMeshMessagingGateway(EGMeshMessagingGeneric):
    def __init__(self):
        EGMeshMessagingGeneric.__init__(self)

    def addHighPriorityMessages(self):
        self.addMessage(EGMeshMessage.Type.SENSOR_DATA)

    def addLowPriorityMessages(self):
        self.addMessage(EGMeshMessage.Type.SENSOR_CONFIG)

# ------------------------------------------------------------------------------------------------------------------
#
# With MESH + MQTT communication runs on a GATEWAY and only announces BROKER address/port
#
class EGMeshMessagingGatewayAnnouncer(EGMeshMessagingGeneric):
    def __init__(self, mqttHandler):
        EGMeshMessagingGeneric.__init__(self)

        self.highPriorityInterval = 5
        self.mqttHandler = mqttHandler

    def addHighPriorityMessages(self):
        try:
            now = int(time.time())
            if self.lastMeshMessage is None or now - self.lastMeshMessage > self.meshMessageExpireInterval:
                status = self.mqttHandler.getStatus()
                status["projectID"] = str(globalSettings.id)

                if status["connected"]:
                    self.addMessage(EGMeshMessage.Type.MESH_INFO, outgoing=True, data=json.dumps(status))
                self.lastMeshMessage = now
        except Exception, e:
            log.error("Cannot send MESH message %s" % e)


    def addLowPriorityMessages(self):
        pass


# ------------------------------------------------------------------------------------------------------------------
#
# With MESH only communication runs on a SENSOR node: Gathers data from local connected sensors
#
class EGMeshMessagingSensorNode(EGMeshMessagingGeneric):
    def __init__(self, sensorDataHandler):
        EGMeshMessagingGeneric.__init__(self)
        self.sensorDataHandler = sensorDataHandler

    def addHighPriorityMessages(self):
        self.addMessage(EGMeshMessage.Type.SENSOR_DATA, outgoing=True, data=self.sensorDataHandler.readSensor().data)

    def addLowPriorityMessages(self):
        self.addMessage(EGMeshMessage.Type.SENSOR_CONFIG, outgoing=True, data=self.sensorDataHandler.readConfig())


# ------------------------------------------------------------------------------------------------------------------
#
# With MESH + MQTT communication runs on SENSOR and discovers MQTT Broker
#
class EGMeshMessagingSensorNodeDiscover(EGMeshMessagingGeneric):
    def __init__(self, mqttHandler):
        EGMeshMessagingGeneric.__init__(self)
        self.mqttHandler = mqttHandler

    def handleResponse(self, meshData):
        # Handle what we received

        type = meshData["type"]
        data = meshData["data"]

        #log.info("Handling MESH data type: %s: %s" % (type, data))

        if type == EGMeshMessage.Type.MESH_INFO:
            id, host, port, timeval = self.__getBrokerDetails(data)
            log.info("Received MESH_INFO message. Project %s master node is connected to MQTT server: %s:%s" % (id, host, port))
            now = int(time.time())

            # TODO implement connection retry when we receive information with multiple interfaces
            self.mqttHandler.host = host
            self.mqttHandler.port = port

            if id is None:
                id = "None"
            if id != globalSettings.id:
                globalSettings.id = id
                log.info("Received new Project ID: %s" % globalSettings.id)
                self.mqttHandler.onTopicsChange()

            if timeval is not None:
                # check if time more than 1 min behind (no check for ahead) 
                if timeval > (now + 6000): 
                    log.info("Timeval is %d, now is %d, adjust clock" % (timeval, now))
                    timeval = timeval - 18000 # back 5 hours from GMT for DST
                    #datestr = datetime.datetime.utcfromtimestamp(timeval).strftime('%Y-%m-%dT%H:%M:%SZ')
                    datestr = datetime.datetime.utcfromtimestamp(timeval).strftime('%d %b %Y %H:%M:%S')
                    log.info("date -s %s" % datestr)
                    save_path = '/home/pi/newclk'
                    file1 = open(save_path, "w")
                    file1.write(datestr)
                    file1.write("\n")
                    file1.close()
                    #subprocess.call(['date', '-s', '{:}'.format(timeval.strftime('%Y/%m/%d %H:%M:%S'))], shell=True)
                    subprocess.call(['/home/pi/setDate.sh'], shell=False)

    def addHighPriorityMessages(self):
        # We need to send a "read message" request to check for project id changes
        self.addMessage(EGMeshMessage.Type.MESH_INFO)

        if not self.mqttHandler.isConnected:
            log.info("Node not connected to MQTT server, looking for MESH_INFO published messages")


    def addLowPriorityMessages(self):
        pass


    def __getBrokerDetails(self, data):
        try:
            port = None
            host = None
            id = None
            timeval = None

            for sender in data:
                # TODO Encoded twice as JSON !
                meshMessage = json.loads(data[sender])
                actualMessage = json.loads(meshMessage)
                id = actualMessage.get("projectID")
                timeval = actualMessage.get("time")

                if not actualMessage["connected"]:
                    log.info("Skipping unconnected sender : %s" % sender)
                    continue
                else:
                    log.info("Found connected sender : %s" % sender)

                port = actualMessage["port"]
                for interface in actualMessage["host"]:
                    if actualMessage["host"][interface]["ipv6"] is not None:
                        host = actualMessage["host"][interface]["ipv6"]
                        return id, host, port, timeval
            return globalSettings.id, host, port, "None" 

        except Exception, e:
            log.error("Cannot choose Broker HOST and PORT can't parse data : %s" % e)

        return None, None, None, None
