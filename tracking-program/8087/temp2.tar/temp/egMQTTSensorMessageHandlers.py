
from EGCommon.egLogging import log
import json

from EGCommon.egMainManager import EGMainManager
from EGDatabase.egDatabaseManager import globalDBManager

import time

class EGMQTTSensorMessageHandlers:

    def __init__(self, owner):
        self.owner = owner

    # ------------------------------------------------------------------------------------------------------------------
    #
    # Handlers for sensor messages types
    #
    def handleControlMessage(self, msg):
        log.info("[Node on_message] [Control message] on %s with payload %s" % (msg.topic, str(msg.payload)))
        try:
            data = json.loads(msg.payload)
            # New reboot command format: /control {"reboot": "<uuid>"}
            # Check if we received a reboot: true command
            rebootStr = data.get("reboot")
            if rebootStr is not None:
                idStr = data["reboot"]
                wasUsed = globalDBManager.rebootTable.checkUUID(idStr)
                if wasUsed:
                    log.info("Detected previously used reboot command on control topic: %s" % idStr)
                else:
                    log.info("Detected REBOOT command on control topic")
                    # self.owner.publishRebootAck()
                    globalDBManager.rebootTable.addUUID(idStr)
                    EGMainManager.instance.reboot("Reboot control message received")                        
            else:
                # Try to parse a schedule control message
                scheduleid = data["schedule"]
                itemid = data["id"]
                command = data["command"]
                timestamp = data["time"]
                globalDBManager.nodesScheduleTable.setRecord(str(scheduleid), str(itemid), str(command), str(timestamp))
                #Publish added ACK message
                self.owner.publishScheduleAck(itemid, "added")
                    
        except Exception, e:
            log.error("Error Control Handler: %s" %e)

    def handleUpdateMessage(self, msg):
        log.info("[Node on_message] [Update message] on %s with payload %s" % (msg.topic, str(msg.payload)))
        EGMainManager.instance.performUpdateIfNeeded()

    def handleSwitchMessage(self, msg):
        log.info("[Node on_message] [Switch message] on %s with payload %s" % (msg.topic, str(msg.payload)))
        try:
            data = json.loads(msg.payload)
            status = data["status"]
            currentValue = self.owner.switch.get()
            if status != currentValue:
                # at the same time as we set the gpio, send modbus command
                #pull it from /var/tmp/sdmlog
                if (status): 
                    f = open("/home/pi/turnoff","w")
                else:
                    f = open("/home/pi/turnon","w")
                f.writeline(status)
                f.close()
                log.info("Turning SWITCH to %s" % status)
                self.owner.switch.set(int(status))
                self.owner.currentSwitchValue = self.owner.switch.get()
                self.owner.refreshSwitchStatus = True
                log.info("Switch status is now %s", self.owner.currentSwitchValue)
                # Save timestamp for last command
                self.owner.lastSwitchCmdTimeStamp = int(time.time())
                # Publish Ack
                self.owner.publishSwitchAck(int(status))
            else:
                log.info("Switch change command has the same value as the current switch value.")
        except Exception, e:
            log.error("Switch Handler: %s" % e)
            
    def handleCancelControlMessage(self, msg):
        log.info("[Node on_message] [CancelControl message] on %s with payload %s" % (msg.topic, str(msg.payload)))
        try:
            data = json.loads(msg.payload)
            scheduleid = data["schedule"]
            globalDBManager.nodesScheduleTable.deleteSchedule(str(scheduleid))

            # Publish removed ACK message
            self.owner.publishScheduleAck(scheduleid, "removed")
        except Exception, e:
            log.error("CancelControl Handler : %s" %e)

